import pandas as pd
import gensim
import re

def __doc_to_vec(text):
	words = re.findall(r"\w+",text)
	return [word.lower() for word in words]

train_fn = 'master_train.csv'
test_fn = 'master_test.csv'
unprocessed_train_data = pd.read_csv(train_fn)['Company Description'].tolist()
processed_train_data = [' '.join(__doc_to_vec(sentence)) for sentence in unprocessed_train_data]
unprocessed_train_data.extend(processed_train_data)
model = gensim.models.Word2Vec(unprocessed_train_data, min_count=1)
model.save("word_movers.model")
