import os
import sys
import math
import glob
import numpy as np
import pandas as pd

percentage = 0.01

dataset = pd.read_csv('master_train.csv')
# Train/Test Split
dataset['split'] = np.random.randn(dataset.shape[0], 1)
mask = np.random.rand(len(dataset)) <= percentage
train = dataset[mask].drop(columns=['split'])
test = dataset[~mask].drop(columns=['split'])
train.to_csv('reduced_train.csv')
