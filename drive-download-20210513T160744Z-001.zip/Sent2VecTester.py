from Similarity_Engine import Similarity_Engine
from ProgressBar import ProgressBar
import pandas as pd
import os

# Similarity Metric System
current_similarity_metric = 'BERT'

sim_engine = Similarity_Engine()

# Get all descriptions of children for each parent=============================
train_file = 'reduced_train.csv'
train_df = pd.read_csv(train_file)
test_files = []
for file in os.listdir('test_subsets'):
  if file.endswith('.csv'):
    test_files.append(os.path.join('test_subsets', file))
all_investor_names = train_df['True Investor'].unique()
pbar = ProgressBar(pd.read_csv(test_files[0]).shape[0] * len(test_files) * train_df.shape[0])


# input two strings, get their similarity
def calculate_similarity(docA, docB):
    global pbar
    x = sim_engine.sent2vec(docA, docB)
    pbar.make_progress(1)
    return x
    
def get_average_similarity(multiple_descriptions, single_description):
    similarity = 0.0
    for description in multiple_descriptions:
        similarity += calculate_similarity(description, single_description)
    similarity /= len(multiple_descriptions)
    return similarity
    
def empty_output_dataframe():
  output_columns = ['Company Name', 'Company Description', 'True Investor', 'Similarity Metric']
  for investor in all_investor_names:
      output_columns.append(investor)
  return pd.DataFrame(columns = output_columns)


def get_children_descriptions_for_parent(parent):
    parent_df = train_df.loc[train_df['True Investor'] == parent]
    return parent_df['Company Description'].tolist()

child_descriptions_for_parent = dict()
for parent in all_investor_names:
    child_descriptions_for_parent[parent] = get_children_descriptions_for_parent(parent)

# Write empty dataframe
output_df_filename = os.path.join('Scored_Files', current_similarity_metric + '_output' + '.csv')
empty_output_dataframe().to_csv(output_df_filename, index=True)


def process_similarity(test_set):
    output_df = pd.read_csv(output_df_filename)
    for index, test_row in test_set.iterrows():
        tmp_dict = dict()
        tmp_dict['Company Name'] = test_row['Company Name']
        tmp_dict['Company Description'] = test_row['Company Description']
        tmp_dict['True Investor'] = test_row['True Investor']
        tmp_dict['Similarity Metric'] = current_similarity_metric
        for parent in all_investor_names:
            # for TFIDF, replace the next three lines with:
            #tmp_dict[parent] = sim_engine.tfidf(tmp_dict['Company Name'], parent)
            children_descriptions = child_descriptions_for_parent[parent]
            average_similarity = get_average_similarity(children_descriptions, tmp_dict['Company Description'])
            tmp_dict[parent] = average_similarity
        output_df = output_df.append(tmp_dict, ignore_index=True)
        output_df.to_csv(output_df_filename, index=True)
        print('Column written!')


for test_file in test_files:
	process_similarity(pd.read_csv(test_file))
