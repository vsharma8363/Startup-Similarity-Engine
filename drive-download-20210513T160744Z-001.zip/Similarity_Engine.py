import re
from collections import Counter
import gensim
import os
import sys
import math
import glob
import numpy as np
import pandas as pd
from scipy import spatial
from sent2vec.vectorizer import Vectorizer

class Similarity_Engine:

  train_dictionary = dict()
  test_dictionary = dict()

  def __init__(self, train_fn = 'master_train.csv', test_fn = 'master_test.csv'):
    print('Initializing Similarity Engine...')
    print('Initializing TFIDF values...')
    self.__initialize_tfidf(train_fn, test_fn)
    print('Loading Word Movers Distance Model...')
    self.model = gensim.models.Word2Vec.load("word_movers.model")
    print('Initializing BERT...')
    self.vectorizer = Vectorizer()
    print('Full initialized Similarity Metrics!', '\n')


  def __doc_to_vec(self, text):
      words = re.findall(r"\w+",text)
      return [word.lower() for word in words]

  # Calculate the mathy cosine similarity between 2 vectors
  def __cos_similarity(self, vector1, vector2):
    numerator = np.sum(vector1 * vector2)
    denom1 = np.sum(vector1 * vector1)
    denom2 = np.sum(vector2 * vector2)
    if denom1 == 0 or denom2 == 0:
        return 0.0
    return numerator / np.sqrt(denom1 * denom2)

  # Jaccard Similarity
  def jaccard(self, docA, docB):
    # basic split by whitespace, but we could also split with other characters
    setA = set(self.__doc_to_vec(docA))
    setB = set(self.__doc_to_vec(docB))
    intersections = setA.intersection(setB)
    return float(len(intersections)) / (len(setA) + len(setB) - len(intersections))

  # Cosine Similarity
  def cosine(self, docA, docB):
    vecA = self.__doc_to_vec(docA)
    vecB = self.__doc_to_vec(docB)
    tfA = dict(Counter(vecA)) # Term frequency for A
    tfB = dict(Counter(vecB)) # Term frequency for B
    docA_vec = []
    docB_vec = []
    for word in tfA:
      docA_vec.append(tfA[word])
      if word in tfB:
        docB_vec.append(tfB[word])
      else:
        docB_vec.append(0)
    docA_vec = np.array(docA_vec)
    docB_vec = np.array(docB_vec)
    # Calculate cosine similarity
    return self.__cos_similarity(docA_vec, docB_vec)

  # TF-IDF scoring
  def __calculate_tfidf(self, documents):
    num_documents_with_word = dict() # word: idf value
    for document in documents:
      for word in document:
        if word not in num_documents_with_word:
          num_documents_with_word[word] = 1
        else:
          num_documents_with_word[word] += 1
    total_num_documents = len(documents)
    for document in documents:
      for word in document:
        tf = document[word]
        idf = np.log(total_num_documents / num_documents_with_word[word])
        document[word] = tf * idf

  def __initialize_tfidf(self, train_fn, test_fn):
    test_df = pd.read_csv(test_fn)
    train_df = pd.read_csv(train_fn)
    all_investor_names = train_df['True Investor'].unique()
    # Calculate TFIDF values for all abstracts (parents)
    for parent in all_investor_names:
      descriptions = train_df.loc[train_df['True Investor'] == parent]['Company Description'].tolist()
      all_train_descriptions = [dict(Counter(self.__doc_to_vec(description))) for description in descriptions]
      self.__calculate_tfidf(all_train_descriptions)
      self.train_dictionary[parent] = all_train_descriptions
    # Calculate TFIDF values for all queries (tests)
    all_test_names = test_df['Company Name'].tolist()
    all_test_descriptions = [dict(Counter(self.__doc_to_vec(description))) for description in test_df['Company Description'].tolist()]
    self.__calculate_tfidf(all_test_descriptions)
    for idx in range(0, len(all_test_names)):
      child_name = all_test_names[idx]
      child_description = all_test_descriptions[idx]
      self.test_dictionary[child_name] = child_description

  def __cos_sim_for_tfidf(self, query, abstract):
    query_vector = []
    abstract_vector = []
    for word in query:
        query_vector.append(query[word])
        if word in abstract:
            abstract_vector.append(abstract[word])
        else:
            abstract_vector.append(0)
    abstract_vec = np.array(abstract_vector)
    query_vec = np.array(query_vector)
    # Calculate cosine similarity
    numerator = np.sum(abstract_vec * query_vec)
    denom1 = np.sum(abstract_vec * abstract_vec)
    denom2 = np.sum(query_vec * query_vec)
    if denom1 == 0 or denom2 == 0:
        return 0.0
    return numerator / np.sqrt(denom1 * denom2)

  def tfidf(self, child_name, parent_name):
    similarity = 0.0
    for description in self.train_dictionary[parent_name]:
        similarity += self.__cos_sim_for_tfidf(description, self.test_dictionary[child_name])
    similarity /= len(self.train_dictionary[parent_name])
    return similarity

  # WMD (Word Movers Distance)
  def wmd(self, docA, docB):
    return self.model.wv.wmdistance(docA, docB)
    
  def sent2vec(self, docA, docB):
    self.vectorizer.bert([docA, docB])
    vectors_bert = self.vectorizer.vectors  	
    return spatial.distance.cosine(vectors_bert[0], vectors_bert[1])

#sim_engine = Similarity_Engine()
#print('Jaccard: ', sim_engine.jaccard(docA, docB))
#print('Cosine:', sim_engine.cosine(docA, docB))
#print('TFIDF:', sim_engine.tfidf('CrowdAI', '500 Startups'))
#print('WMD:', sim_engine.wmd(docA, docB))
