import os
import sys
import math
import glob
import numpy as np
import pandas as pd
from sklearn.metrics import confusion_matrix
from sklearn import preprocessing

percentage = 0.5

print('Testing top', percentage * 100.0, ' ===========!!!!!')

dataset = pd.read_csv('master_dataset.csv').set_index('Company Name') 
	
output_files = ['word_movers_distance_output.csv']
  
def less_metrics(output_df, threshold):
	accuracy = 0
	precision = 0
	recall = 0
	f1 = 0
	count = 0
	all_investors = output_df['True Investor'].unique().tolist()
	for index, similar_row in output_df.iterrows():
		TP = 0
		TN = 0
		FP = 0
		FN = 0
		true_investors = []
		investor_names = dataset.loc[similar_row['Company Name']]['Investor Names']
		for inv in investor_names:
			i = inv.split(', ')
			for x in i:
				if x not in true_investors and x in all_investors:
					true_investors.append(x)
		predicted_investors = similar_row[-30:]
		predicted_investors = predicted_investors.where(predicted_investors < threshold).dropna().index.tolist()
		for true in true_investors:
			if true in predicted_investors:
				TP += 1
			else:
				FN += 1
		for investor in all_investors:
			if investor not in true_investors and investor not in predicted_investors:
				TN += 1
			elif investor in predicted_investors and investor not in true_investors:
				FP += 1
		if (TP+TN+FP+FN) > 0:
			accuracy += (TP+TN)/(TP+TN+FP+FN)
		if (TP+FP) > 0:
			precision += TP/(TP+FP)
		if (TP+FN) > 0:
			recall += TP/(TP+FN)
		if (2*TP + FP + FN) > 0:
			f1 += (2 * TP) / (2*TP + FP + FN)
		count += 1
		
	return accuracy/count, precision/count, recall/count, f1/count

  
def get_bottom_percent(output_df, bottom=percentage):
	output_df = output_df[output_df.columns[-30:]]
	all_values = []
	for column in output_df:
		for element in output_df[column].tolist():
			all_values.append(element)
	vals = np.sort(np.array(all_values))
	s = len(output_df['Techstars'])
	num_items_in_top_x_percent = int(bottom * s * 30)
	x = vals[:num_items_in_top_x_percent]
	return x[len(x)-1]

for output_file in output_files:
    
    total_true = 0
    total_false = 0
    output_df = pd.read_csv(output_file)
    threshold = get_bottom_percent(output_df)
    accuracy, precision, recall, f1 = less_metrics(output_df, threshold)
    #accuracy, precision, recall, f1 = process_metrics(TP, TN, FP, FN)
    print(output_file, 'metrics -------')
    print('accuracy', (accuracy))
    print('precision', (precision))
    print('recall', (recall))
    print('f1', (f1))
    print('===============')
