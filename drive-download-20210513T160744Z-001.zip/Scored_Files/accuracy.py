import os
import sys
import math
import glob
import numpy as np
import pandas as pd

output_files = ['tfidf_output.csv', 'cosine_output.csv', 'jaccard_output.csv']

def score_accuracy(dataframe):
  dataframe['Predicted Investor'] = dataframe.iloc[:, dataframe.columns.get_loc('Similarity Metric') + 1:].idxmax(axis=1)
  dataframe['Is Correct'] = np.where(dataframe['Predicted Investor'] == dataframe['True Investor'], True, False)
  return dataframe['Is Correct'].value_counts()

def score_accuracy_wmd(dataframe):
  dataframe['Predicted Investor'] = dataframe.iloc[:, dataframe.columns.get_loc('Similarity Metric') + 1:].idxmin(axis=1)
  dataframe['Is Correct'] = np.where(dataframe['Predicted Investor'] == dataframe['True Investor'], True, False)
  print(dataframe['Is Correct'].value_counts())
  exit()
  return dataframe['Is Correct'].value_counts()


for output_file in output_files:
    total_true = 0
    total_false = 0
    output_df = pd.read_csv(output_file)
    if output_df.shape[0] <= 0:
    	print('No items in ' + str(output_file))
    else:
	    results = score_accuracy(output_df)
	    total_true += results[True]
	    total_false += results[False]
	    if total_false + total_true > 0:
	      print('Accuracy of ' + str(output_file) + ': ' + str(total_true/(total_true + total_false) * 100.0) + "%")
	      
output_file = 'word_movers_distance_output.csv'
total_true = 0
total_false = 0
output_df = pd.read_csv(output_file)
if output_df.shape[0] <= 0:
	print('No items in ' + str(output_file))
else:
    results = score_accuracy_wmd(output_df)
    total_true += results[True]
    total_false += results[False]
    if total_false + total_true > 0:
      print('Accuracy of ' + str(output_file) + ': ' + str(total_true/(total_true + total_false) * 100.0) + "%")
